#include "dop.h"

namespace dop
{
	namespace device_identifiers
	{
		// {1FA01D86-2255-478a-96CE-AE2402F40612}
		const GUID ipod = 
		{ 0x1fa01d86, 0x2255, 0x478a, { 0x96, 0xce, 0xae, 0x24, 0x2, 0xf4, 0x6, 0x12 } };
	}
}