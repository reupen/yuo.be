namespace dop
{
	namespace device_identifiers
	{
		extern const GUID ipod;
	}
}