#ifndef _DOP_SDK_H_
#define _DOP_SDK_H_

#define DOP_SDK_VERSION "0.2"

#include "../SDK/foobar2000.h"
#include "device_identifiers.h"
#include "playback_data.h"
#include "ipod_manager.h"

#endif //_DOP_SDK_H_