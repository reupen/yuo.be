#include "dop.h"

namespace dop
{
	// {05438F13-C331-43fe-8E91-3AB459388209}
	const GUID ipod_manager_control_t::class_guid = 
	{ 0x5438f13, 0xc331, 0x43fe, { 0x8e, 0x91, 0x3a, 0xb4, 0x59, 0x38, 0x82, 0x9 } };

};